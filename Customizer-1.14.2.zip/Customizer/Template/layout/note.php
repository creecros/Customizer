<?php global $customizer; ?>

<div class="form-login">
    <div class="login-note">
        <?= $customizer['login_note'] ?>
    </div>
</div>
